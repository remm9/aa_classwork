

// const timerId = setInterval(this._tick.bind(this), 1000);